/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     RandomGenerator.h

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#ifndef _RANDOMGENERATOR_H_
#define _RANDOMGENERATOR_H_

#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <iostream>

#include "maboss-config.h"

class RandomGenerator {

 public:
  virtual std::string getName() const = 0;

  virtual bool isPseudoRandom() const = 0;

  virtual unsigned int generateUInt32() = 0;

  virtual double generate() = 0;

  virtual void setSeed(int seed) { }
};

class PhysicalRandomGenerator : public RandomGenerator {
  int fd;

 public:
  PhysicalRandomGenerator() {
    fd = open("/dev/urandom", O_RDONLY);
    assert(fd >= 0);
  }

  bool isPseudoRandom() const {
    return false;
  }

  std::string getName() const {
    return "physical";
  }

  unsigned int generateUInt32() {
    unsigned int r;
    int ret = read(fd, &r, sizeof(r));
    assert(ret == sizeof(r));
    return r;
  }

  virtual double generate() {
    return ((double)generateUInt32())/~0U/2;
  }

  ~PhysicalRandomGenerator() {
    if (fd >= 0) {
      close(fd);
    }
  }
};

class StandardRandomGenerator : public RandomGenerator {

  int seed;
#ifdef HAS_DRAND48_T
  drand48_data data;
#endif

 public:
  StandardRandomGenerator(int seed) : seed(seed) {
#ifdef HAS_DRAND48_T
    memset(&data, 0, sizeof(data));
    srand48_r(seed, &data);
#else
    srand48(seed);
#endif
  }

  bool isPseudoRandom() const {
    return true;
  }

  std::string getName() const {
    return "standard";
  }

  unsigned int generateUInt32() {
#ifdef HAS_DRAND48_T
    long result;
    lrand48_r(&data, &result);
    return (unsigned int)result;
#else
    return lrand48();
#endif
  }

  virtual double generate() {
#ifdef HAS_DRAND48_T
    double result;
    drand48_r(&data, &result);
    return result;
#else
    return drand48();
#endif
  }

  virtual void setSeed(int seed) {
    this->seed = seed;
#ifdef HAS_DRAND48_T
    srand48_r(seed, &data);
#else
    srand48(seed);
#endif
  }
};

class RandomGeneratorFactory {

public:
  enum Type {
    STANDARD = 1,
    PHYSICAL
  };

private:
  Type type;

public:
  RandomGeneratorFactory(Type type) : type(type) { }

  RandomGenerator* generateRandomGenerator(int seed) const {
    switch(type) {
    case STANDARD:
      return new StandardRandomGenerator(seed);
    case PHYSICAL:
      return new PhysicalRandomGenerator();
    default:
      abort();
      return NULL;
    }
  }

  std::string getName() const {
    switch(type) {
    case STANDARD:
      return "standard";
    case PHYSICAL:
      return "physical";
    default:
      abort();
      return NULL;
    }
  }

  bool isPseudoRandom() const {
    switch(type) {
    case STANDARD:
      return true;
    case PHYSICAL:
      return false;
    default:
      abort();
      return NULL;
    }
  }

  bool isThreadSafe() const {
    switch(type) {
    case STANDARD:
#ifdef HAS_DRAND48_T
      return true;
#else
      return false;
#endif
    case PHYSICAL:
      return true;
    default:
      abort();
      return NULL;
    }
  }
};

#endif
