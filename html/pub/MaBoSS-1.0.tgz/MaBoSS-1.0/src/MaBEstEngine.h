/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     MaBEstEngine.h

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#ifndef _MABESTENGINE_H_
#define _MABESTENGINE_H_

#include <string>
#include <map>
#include <vector>
#include <assert.h>

#include "BooleanNetwork.h"
#include "Cumulator.h"
#include "RandomGenerator.h"
#include "RunConfig.h"

class MaBEstEngine {

  Network* network;
  double time_tick;
  double max_time;
  unsigned int sample_count;
  bool discrete_time;
  unsigned int thread_count;
  std::vector<NetworkState> fixpoints;
  mutable long long core_run_time, display_time;

  NetworkState reference_state;
  unsigned int refnode_count;
  Cumulator* merged_cumulator;
  std::vector<std::map<unsigned long long, bool>*> fixpoint_map_v;
  std::vector<Cumulator*> cumulator_v;
  NodeIndex getTargetNode(RandomGenerator* random_generator, const std::map<NodeIndex, double>& nodeTransitionRates, double total_rate) const;
  double computeTH(const std::map<NodeIndex, double>& nodeTransitionRates, double total_rate) const;
  void epilogue();
  static void* threadWrapper(void *arg);
  void runThread(Cumulator* cumulator, unsigned int start_count_thread, unsigned int sample_count_thread, RandomGeneratorFactory* randgen_factory, int seed, std::map<unsigned long long, bool>* fixpoint_map, std::ostream* output_traj);
  std::map<unsigned long long, bool>* mergeFixpointMaps();

public:
  static const std::string VERSION;

  MaBEstEngine(Network* network, RunConfig* runconfig);

  void run(std::ostream* output_traj);

  const std::vector<NetworkState>& getFixpoints() const {return fixpoints;}

  bool converges() const {return fixpoints.size() > 0;}

  void display(std::ostream& output_probtraj, std::ostream& output_statdist) const;

  long long getCoreRunTime() const {return core_run_time;}
  long long getDisplayTime() const {return display_time;}

};

#endif
