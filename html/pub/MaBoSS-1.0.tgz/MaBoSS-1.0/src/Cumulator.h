/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     Cumulator.h

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#ifndef _CUMULATOR_H_
#define _CUMULATOR_H_

#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <assert.h>

#include "ProbaDist.h"

class Network;

class Cumulator {

  struct TickValue {
    double tm_slice;
    double TH;
    double tm_slice_square;
    TickValue() {tm_slice = 0.; TH = 0.; tm_slice_square = 0.;}
    TickValue(double tm_slice, double TH) : tm_slice(tm_slice), TH(TH), tm_slice_square(0.0) { }
  };

  struct LastTickValue {
    double tm_slice;
    double TH;
    LastTickValue() : tm_slice(0.0), TH(0.0) {}
    LastTickValue(double tm_slice, double TH) : tm_slice(tm_slice), TH(TH) {}
  };

  class CumulMap {
    std::map<unsigned long long, TickValue> mp;

  public:
    size_t size() const {
      return mp.size();
    }

    void incr(unsigned long long state, double tm_slice, double TH) {
      std::map<unsigned long long, TickValue>::iterator iter = mp.find(state);
      if (iter == mp.end()) {
	mp[state] = TickValue(tm_slice, tm_slice * TH);
      } else {
	(*iter).second.tm_slice += tm_slice;
	(*iter).second.TH += tm_slice * TH;
      }
    }

    void cumulTMSliceSquare(unsigned long long state, double tm_slice) {
      std::map<unsigned long long, TickValue>::iterator iter = mp.find(state);
      assert(iter != mp.end());
      (*iter).second.tm_slice_square += tm_slice * tm_slice;
    }
    
    void add(unsigned long long state, const TickValue& tick_value) {
      std::map<unsigned long long, TickValue>::iterator iter = mp.find(state);
      if (iter == mp.end()) {
	mp[state] = tick_value;
      } else {
	TickValue& to_tick_value = (*iter).second;
	to_tick_value.tm_slice += tick_value.tm_slice;
	to_tick_value.tm_slice_square += tick_value.tm_slice_square;
	to_tick_value.TH += tick_value.TH;
      }
    }

    class Iterator {
    
      const CumulMap& cumul_map;
      std::map<unsigned long long, TickValue>::const_iterator iter, end;

    public:
      Iterator(const CumulMap& cumul_map) : cumul_map(cumul_map) {
	iter = cumul_map.mp.begin();
	end = cumul_map.mp.end();
      }
	
      void rewind() {
	iter = cumul_map.mp.begin();
      }

      bool hasNext() const {
	return iter != end;
      }

      void next(unsigned long long& state, TickValue& tick_value) {
	state = (*iter).first;
	tick_value = (*iter).second;
	++iter;
      }
	
      void next(TickValue& tick_value) {
	tick_value = (*iter).second;
	++iter;
      }
    };

    Iterator iterator() {return Iterator(*this);}
    Iterator iterator() const {return Iterator(*this);}
  };

  double time_tick;
  double max_time;
  unsigned int sample_num;
  unsigned int sample_count;
  double last_tm;
  int tick_index;
  std::vector<double> H_v;
  std::vector<double> TH_v;
  std::vector<std::map<unsigned int, double> > HD_v;
  std::vector<double> TH_square_v;
  unsigned int maxcols;
  unsigned int refnode_count;
  // cumul tick_indexed by tick
  int max_size;
  int max_tick_index;
  unsigned long long output_mask;
  std::vector<CumulMap> cumul_map_v;
  std::vector<ProbaDist> proba_dist_v;
  ProbaDist curtraj_proba_dist;
  std::map<unsigned long long, LastTickValue> last_tick_map;
  bool tick_completed;

  CumulMap& get_map() {
    return cumul_map_v[tick_index];
  }

  CumulMap& get_map(unsigned int nn) {
    return cumul_map_v[nn];
  }

  const CumulMap& get_map(unsigned int nn) const {
    return cumul_map_v[nn];
  }

  double cumultime(int at_tick_index = -1) {
    if (at_tick_index < 0) {
      at_tick_index = tick_index;
    }
    return at_tick_index * time_tick;
  }

  bool incr(unsigned long long state, double tm_slice, double TH, unsigned long long fullstate) {
    if (tm_slice == 0.0) {
      return true;
    }

    curtraj_proba_dist.incr(fullstate, tm_slice);

    if (tick_index >= max_size) {
      return false;
    }
    tick_completed = false;
    CumulMap& mp = get_map();
    mp.incr(state, tm_slice, TH);

    std::map<unsigned long long, LastTickValue>::iterator last_tick_iter = last_tick_map.find(state);
    if (last_tick_iter == last_tick_map.end()) {
      last_tick_map[state] = LastTickValue(tm_slice, tm_slice * TH);
    } else {
      (*last_tick_iter).second.tm_slice += tm_slice;
      (*last_tick_iter).second.TH += tm_slice * TH;
    }

    return true;
    //    curtraj_proba_dist.incr(fullstate, tm_slice);
  }

  void check() const;

  void add(unsigned int where, const CumulMap& add_cumul_map);

public:

  Cumulator(double time_tick, double max_time, unsigned int sample_count) :
    time_tick(time_tick), max_time(max_time), sample_count(sample_count), sample_num(0), last_tm(0.), tick_index(0), output_mask(~0ULL) {
    max_size = (int)(max_time/time_tick)+2;
    max_tick_index = max_size;
    cumul_map_v.resize(max_size);
    TH_square_v.resize(max_size);
    for (unsigned int nn = 0; nn < max_size; ++nn) {
      TH_square_v[nn] = 0.;
    }
    proba_dist_v.resize(sample_count);
    tick_completed = false;
  }

  void rewind() {
    if (last_tm) {
      computeMaxTickIndex();
    }

    tick_index = 0;
    last_tm = 0.;
    last_tick_map.clear();
    curtraj_proba_dist.clear();
    tick_completed = false;
  }

  void next() {
    if (tick_index < max_size) {
      std::map<unsigned long long, LastTickValue>::iterator begin = last_tick_map.begin();
      std::map<unsigned long long, LastTickValue>::iterator end = last_tick_map.end();
      CumulMap& mp = get_map();
      double TH = 0.0;
      while (begin != end) {
	unsigned long long state = (*begin).first;
	double tm_slice = (*begin).second.tm_slice;
	TH += (*begin).second.TH;
	mp.cumulTMSliceSquare(state, tm_slice);
	++begin;
      }
      TH_square_v[tick_index] += TH * TH;
    }
    ++tick_index;
    tick_completed = true;
    last_tick_map.clear();
  }

  void cumul(const NetworkState& network_state, double tm, double TH) {
    unsigned long long fullstate = network_state.getState();
    unsigned long long state = (fullstate & output_mask);
    double time_1 = cumultime(tick_index+1);
    if (tm < time_1) {
      incr(state, tm - last_tm, TH, fullstate);
      last_tm = tm;
      return;
    }

    if (!incr(state, time_1 - last_tm, TH, fullstate)) {
      last_tm = tm;
      return;
    }
    next();

    for (; cumultime(tick_index+1) < tm; next()) {
      if (!incr(state, time_tick, TH, fullstate)) {
	last_tm = tm;
	return;
      }
    }
      
    incr(state, tm - cumultime(), TH, fullstate);
    last_tm = tm;
  }

  void setOutputMask(unsigned long long output_mask) {
    this->output_mask = output_mask;
  }

  void displayCSV(Network* network, unsigned int refnode_count, std::ostream& os_probtraj = std::cout, std::ostream& os_statdist = std::cout) const;

  void computeMaxTickIndex();
  void epilogue(Network* network, const NetworkState& reference_state);
  void trajectoryEpilogue();

  unsigned int getSampleCount() const {return sample_count;}

  static Cumulator* mergeCumulators(std::vector<Cumulator*>& cumulator_v);
};

#endif
