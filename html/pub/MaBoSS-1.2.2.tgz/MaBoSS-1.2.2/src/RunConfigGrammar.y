
%{
/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     RunConfigGrammar.l

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#include "BooleanNetwork.h"
#include "RunConfig.h"

extern int yylex();
static void yyerror(const char *s);
static Network* network;
%}

%union {
  Expression* expr;
  char* str;
  double d;
  long long l;
}

%type<expr> primary_expression 
%type<expr> postfix_expression 
%type<expr> unary_expression 
%type<expr> multiplicative_expression 
%type<expr> additive_expression 
%type<expr> relational_expression 
%type<expr> equality_expression
%type<expr> logical_and_expression
%type<expr> logical_or_expression
%type<expr> logical_xor_expression
%type<expr> conditional_expression
%type<expr> expression

%token<str> VARIABLE
%token<str> SYMBOL
%token<d> DOUBLE
%token<l> INTEGER

%token LOGAND LOGOR LOGXOR LOGNOT EQUAL NOT_EQUAL NODE GTEQ LTEQ

%%

translation_unit: decl
{
}
| translation_unit decl
{
}
;

decl: var_decl
| runconfig_decl
| node_attr_decl
;

runconfig_decl: SYMBOL '=' expression ';'
{
  NetworkState network_state;
  double value = $3->eval(NULL, network_state);
  RunConfig::getInstance()->setParameter($1, value);
}
;

node_attr_decl: SYMBOL '.' SYMBOL '=' expression ';'
{
  Node* node = network->getNode($1);
  NetworkState network_state;
  double value = $5->eval(NULL, network_state);
  if (!strcasecmp($3, "istate")) {
    node->setIState((bool)value);
  } else if (!strcasecmp($3, "is_internal")) {
    node->isInternal((bool)value);
  } else if (!strcasecmp($3, "refstate")) {
    node->setReferenceState((NodeState)value);
  } else {
    throw BNException(std::string("configuration parsing: invalid node attribute: ") + $3 + ", valid attributes are: istate or is_internal");
  }
}
;

var_decl: VARIABLE '=' expression ';'
{
  SymbolTable* symtab = SymbolTable::getInstance();
  const Symbol* symbol = symtab->getOrMakeSymbol($1);
  NetworkState dummy_state;
  symtab->setSymbolValue(symbol, $3->eval(NULL, dummy_state));
}
;

primary_expression: INTEGER
{
  $$ = new ConstantExpression($1);
}
| DOUBLE
{
  $$ = new ConstantExpression($1);
}
| VARIABLE
{
  $$ = new SymbolExpression(SymbolTable::getInstance()->getOrMakeSymbol($1));
}
| '(' expression ')'
{
  $$ = new ParenthesisExpression($2);
}
;

postfix_expression: primary_expression
{
  $$ = $1;
}
;

unary_expression: postfix_expression
{
  $$ = $1;
}
| '+' unary_expression
{
  $$ = $2;
}
| '-' unary_expression
{
  $$ = new SubExpression(new ConstantExpression(0.0), $2);
}
| '!' unary_expression
{
  $$ = new NotLogicalExpression($2);
}
| LOGNOT unary_expression
{
  $$ = new NotLogicalExpression($2);
}
;

multiplicative_expression: unary_expression
{
  $$ = $1;
}
| multiplicative_expression '*' unary_expression
{
  $$ = new MulExpression($1, $3);
}
| multiplicative_expression '/' unary_expression
{
  $$ = new DivExpression($1, $3);
}
;

additive_expression: multiplicative_expression
{
  $$ = $1;
}
| additive_expression '+' multiplicative_expression
{
  $$ = new AddExpression($1, $3);
}
| additive_expression '-' multiplicative_expression
{
  $$ = new SubExpression($1, $3);
}
;

relational_expression: additive_expression
{
  $$ = $1;
}
| relational_expression '<' additive_expression
{
  $$ = new LetterExpression($1, $3);
}
| relational_expression '>' additive_expression
{
  $$ = new GreaterExpression($1, $3);
}
| relational_expression LTEQ additive_expression
{
  $$ = new LetterOrEqualExpression($1, $3);
}
| relational_expression GTEQ additive_expression
{
  $$ = new GreaterOrEqualExpression($1, $3);
}
;

equality_expression: relational_expression
{
  $$ = $1;
}
| equality_expression EQUAL relational_expression
{
  $$ = new EqualExpression($1, $3);
}
| equality_expression NOT_EQUAL relational_expression
{
  $$ = new NotEqualExpression($1, $3);
}
;

logical_and_expression: equality_expression
{
  $$ = $1;
}
| logical_and_expression LOGAND equality_expression
{
  $$ = new AndLogicalExpression($1, $3);
}
;

logical_or_expression: logical_and_expression
{
  $$ = $1;
}
| logical_or_expression LOGOR logical_and_expression
{
  $$ = new OrLogicalExpression($1, $3);
}
;

logical_xor_expression: logical_or_expression
{
  $$ = $1;
}
| logical_xor_expression LOGXOR logical_or_expression
{
  $$ = new XorLogicalExpression($1, $3);
}
| logical_xor_expression '^' logical_or_expression
{
  $$ = new XorLogicalExpression($1, $3);
}
;

conditional_expression: logical_xor_expression
{
  $$ = $1;
}
| logical_xor_expression '?' expression ':' conditional_expression
{
  $$ = new CondExpression($1, $3, $5);
}
;

expression: conditional_expression
{
  $$ = $1;
}
;

%%

void runconfig_setNetwork(Network* _network)
{
  network = _network;
}

#include "lex.RC.cc"
