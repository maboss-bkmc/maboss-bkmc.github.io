/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     BooleanNetwork.cc

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#include "BooleanNetwork.h"
#include "BooleanGrammar.h"
#include "RunConfig.h"
#include <iostream>

Network* Network::instance;
SymbolTable* SymbolTable::instance;
extern FILE* CTBNDLin;
extern int CTBNDLparse();

bool Node::isInputNode() const
{
  return getLogicalInputExpression() == NULL && getRateUpExpression() == NULL && getRateDownExpression() == NULL;
}

int Network::parse(const char* file)
{
  if (NULL != file) {
    CTBNDLin = fopen(file, "r");
    if (CTBNDLin == NULL) {
      throw BNException("network parsing: cannot open file:" + std::string(file) + " for reading");
    }
  }

  set_current_network(this);
  int r = CTBNDLparse();
  set_current_network(NULL);
  if (r) {
    return 1;
  }
  compile();
  return 0;
}

void SymbolTable::display(std::ostream& os) const
{
  MAP<std::string, Symbol*>::const_iterator begin = symb_map.begin();
  MAP<std::string, Symbol*>::const_iterator end = symb_map.end();

  while (begin != end) {
    double value = getSymbolValue((*begin).second);
    os << (*begin).first << " = " << value << ";\n";
    ++begin;
  }
}

void Network::updateRandomGenerator(RunConfig* runconfig)
{
  random_generator = runconfig->getRandomGeneratorFactory()->generateRandomGenerator(runconfig->getSeedPseudoRandom());
}

void Network::compile()
{
  MAP<std::string, Node*>::iterator begin = node_map.begin();
  MAP<std::string, Node*>::iterator end = node_map.end();

#if 0
  // checks for cycles
  // actually, not really pertinent...
  while (begin != end) {
    Node* node = (*begin).second;
    if (!node->isInputNode()) {
      if (node->getLogicalInputExpr()->getRateUpExpression()->hasCycle(node)) {
	//std::cerr << "cycle detected for node " << node->getLabel() << '\n';
      }
    }
    ++begin;
  }
#endif

  // looks for input and non input nodes
  begin = node_map.begin();
  while (begin != end) {
    Node* node = (*begin).second;
    if (!NodeDecl::isNodeDefined(node->getLabel())) {
      throw BNException("node " + node->getLabel() + " used but not defined"); 
    }
    ++begin;
  }

  begin = node_map.begin();
  nodes.resize(node_map.size());
  while (begin != end) {
    Node* node = (*begin).second;
    if (node->isInputNode()) {
      input_nodes.push_back(node);
    } else {
      non_input_nodes.push_back(node);
    }
    //nodes.push_back(node);
    nodes[node->getIndex()] = node;
    ++begin;
  }
}

Node* Network::defineNode(const std::string& label, const std::string& description)
{
  if (NodeDecl::isNodeDefined(label)) {
    throw BNException("node " + label + " already defined");
  }
  Node* node = new Node(label, description, last_index++); // node factory
  NodeDecl::defineNode(label);
  node_map[label] = node;
  return node;
}

Node* Network::getNode(const std::string& label)
{
  if (node_map.find(label) == node_map.end()) {
    throw BNException("network: node " + label + " not defined");
  }
  return node_map[label];
}

void Network::initStates(NetworkState& initial_state)
{
  std::vector<Node*>::const_iterator begin = nodes.begin();
  std::vector<Node*>::const_iterator end = nodes.end();
  
  while (begin != end) {
    Node* node = *begin;
    initial_state.setNodeState(node, node->getIState(this));
    ++begin;
  }
}

void Network::display(std::ostream& os) const
{
  std::vector<Node*>::const_iterator begin = nodes.begin();
  std::vector<Node*>::const_iterator end = nodes.end();

  for (unsigned int nn = 0; begin != end; ++nn) {
    Node* node = *begin;
    if (0 != nn) {
      os << '\n';
    }
    node->display(os);
    ++begin;
  }
}

double Node::getRateUp(const NetworkState& network_state) const
{
  if (getRateUpExpression() == NULL) {
    if (NULL != getLogicalInputExpression()) {
      double d = getLogicalInputExpression()->eval(this, network_state);
      return (0.0 != d) ? 1.0 : 0.0;
    }
    return 0.0;
  }
  return getRateUpExpression()->eval(this, network_state);
}

double Node::getRateDown(const NetworkState& network_state) const
{
  if (getRateDownExpression() == NULL) {
    if (NULL != getLogicalInputExpression()) {
      double d = getLogicalInputExpression()->eval(this, network_state);
      return (0.0 != d) ? 0.0 : 1.0;
    }
    return 0.0;
  }
  return getRateDownExpression()->eval(this, network_state);
}

NodeState Node::getNodeState(const NetworkState& network_state) const
{
  return network_state.getNodeState(this);
}

void Node::setNodeState(NetworkState& network_state, NodeState state)
{
  network_state.setNodeState(this, state);
}

bool Node::computeNodeState(NetworkState& network_state, NodeState& node_state) const
{
  return network_state.computeNodeState(this, node_state);
}

NodeState Node::getIState(const Network* network) const
{
  if (!istate_set) {
    istate = (network->getRandomGenerator()->generateUInt32() % 2) == 0;
  }
  return istate;
}

void Node::display(std::ostream& os) const
{
  os << "node " << label << " {\n";
  os << "  description = \"" << description << "\";\n";
  if (NULL != logicalInputExpr) {
    os << "  logic = ";
    logicalInputExpr->display(os);
    os << ";\n";
  }
  if (NULL != rateUpExpr) {
    os << "  rate_up = ";
    rateUpExpr->display(os);
    os << ";\n";
  }
  if (NULL != rateDownExpr) {
    os << "  rate_down = ";
    rateDownExpr->display(os);
    os << ";\n";
  }

  if (attr_expr_map.size() || attr_str_map.size()) {
    os << "\n  // extra attributes\n";
    MAP<std::string, const Expression*>::const_iterator attr_expr_begin = attr_expr_map.begin();
    MAP<std::string, const Expression*>::const_iterator attr_expr_end = attr_expr_map.end();
    while (attr_expr_begin != attr_expr_end) {
      os << "  " << (*attr_expr_begin).first << " = ";
      (*attr_expr_begin).second->display(os);
      os << ";\n";
      ++attr_expr_begin;
    }

    MAP<std::string, std::string>::const_iterator attr_str_begin = attr_str_map.begin();
    MAP<std::string, std::string>::const_iterator attr_str_end = attr_str_map.end();
    while (attr_str_begin != attr_str_end) {
      os << "  " << (*attr_str_begin).first << " = \"" << (*attr_str_begin).second << "\";\n";
      ++attr_str_begin;
    }
  }
  os << "}\n";
}

bool NetworkState::computeNodeState(const Node* node, NodeState& node_state)
{
  const Expression* expr = node->getLogicalInputExpression();
  if (NULL != expr) {
    double d = expr->eval(node, *this);
    node_state = d != 0.;
    setNodeState(node, node_state);
    return true;
  }
  return false;
}

#define HAMMING_METHOD2

unsigned int NetworkState::hamming(Network* network, NetworkState_Impl state2) const
{
  unsigned int hd = 0;
#ifdef HAMMING_METHOD1
  // faster way
  unsigned long s = (state ^ (state2 & state));
  unsigned int node_count = network->getNodes().size();
  for (unsigned int nn = 0; nn < node_count; ++nn) {
    if ((1ULL << nn) & s) {
      hd++;
    }
  }
  return hd;
#endif

#ifdef HAMMING_METHOD2
  NetworkState network_state2(state2);
  const std::vector<Node*>& nodes = network->getNodes();
  std::vector<Node*>::const_iterator begin = nodes.begin();
  std::vector<Node*>::const_iterator end = nodes.end();

  while (begin != end) {
    Node* node = *begin;
    if (node->isReference()) {
      NodeState node_state1 = getNodeState(node);
      NodeState node_state2 = network_state2.getNodeState(node);
      hd += 1 - (node_state1 == node_state2);
    }
    ++begin;
  }

  return hd;
#endif
}

void NetworkState::display(std::ostream& os, Network* network, const std::string& indent) const
{
  const std::vector<Node*>& nodes = network->getNodes();
  std::vector<Node*>::const_iterator begin = nodes.begin();
  std::vector<Node*>::const_iterator end = nodes.end();

  while (begin != end) {
    Node* node = *begin;
    os << indent << "Node " << node->getLabel() << ": " << getNodeState(node) << '\n';
    ++begin;
  }
}

void NetworkState::displayOneLine(std::ostream& os, Network* network, const std::string& sep) const
{
#if defined(USE_BITSET) || defined(USE_BOOST_BITSET)
  if (state.none()) {
    os << "<nil>";
    return;
  }
#else
  if (!state) {
    os << "<nil>";
    return;
  }
#endif

  const std::vector<Node*>& nodes = network->getNodes();
  std::vector<Node*>::const_iterator begin = nodes.begin();
  std::vector<Node*>::const_iterator end = nodes.end();

  bool displayed = false;
  while (begin != end) {
    Node* node = *begin;
    if (getNodeState(node)) {
      if (displayed) {
	os << sep;
      } else {
	displayed = true;
      }
      os << node->getLabel();
    }
    ++begin;
  }
}

std::ostream& operator<<(std::ostream& os, const BNException& e)
{
  os << "BooleanNetwork exception: " << e.getMessage() << '\n';
  return os;
}
