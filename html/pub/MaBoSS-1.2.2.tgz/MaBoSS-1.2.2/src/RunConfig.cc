/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     RunConfig.cc

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#include "RunConfig.h"
#include "BooleanNetwork.h"
#include "MaBEstEngine.h"

RunConfig* RunConfig::instance;
static const std::string VERSION = "1.0";

RunConfig::RunConfig()
{
  time_tick = 0.5;
  max_time = 1000.;
  sample_count = 10000;
  discrete_time = false;
  use_physrandgen = true;
  seed_pseudorand = 0;
  randgen_factory = NULL;
  display_traj = false;
  thread_count = 1;
  statdist_traj_count = 0;
  statdist_cluster_threshold = 1.0;
  statdist_similarity_cache_max_size = 20000;
}

void RunConfig::setParameter(const std::string& param, double value)
{
  const char* str = param.c_str();
  if (!strcasecmp(str, "time_tick")) {
    time_tick = value;
  } else if (!strcasecmp(str, "max_time")) {
    max_time = value;
  } else if (!strcasecmp(str, "sample_count")) {
    sample_count = (int)value;
  } else if (!strcasecmp(str, "discrete_time")) {
    discrete_time = (bool)value;
  } else if (!strcasecmp(str, "use_physrandgen")) {
    use_physrandgen = (bool)value;
  } else if (!strcasecmp(str, "seed_pseudorandom")) {
    seed_pseudorand = (int)value;
  } else if (!strcasecmp(str, "display_traj")) {
    display_traj = (bool)value;
  } else if (!strcasecmp(str, "statdist_traj_count")) {
    statdist_traj_count = (unsigned int)value;
  } else if (!strcasecmp(str, "statdist_cluster_threshold")) {
    statdist_cluster_threshold = value;
  } else if (!strcasecmp(str, "thread_count")) {
    thread_count = (unsigned int)value;
  } else if (!strcasecmp(str, "statdist_similarity_cache_max_size")) {
    statdist_similarity_cache_max_size = (unsigned int)value;
  } else {
    throw BNException("configuration: invalid parameter " + param + ", valid parameters are: " +
		      "thread_count, time_tick, max_time, sample_count, discrete_time, statdist_traj_count, statdist_cluster_threshold, display_traj, statdist_similarity_cache_max_size, use_physrandgen or seed_pseudorandom");
  }
}

RandomGeneratorFactory* RunConfig::getRandomGeneratorFactory() const
{
  if (NULL == randgen_factory) {
    if (use_physrandgen) {
      randgen_factory = new RandomGeneratorFactory(RandomGeneratorFactory::PHYSICAL);
    } else {
      randgen_factory = new RandomGeneratorFactory(RandomGeneratorFactory::STANDARD);
    }
  }
  return randgen_factory;
}

void RunConfig::display(Network* network, time_t start_time, time_t end_time, MaBEstEngine& mabest, std::ostream& os) const
{
  const char sepfmt[] = "-----------------------------------------------%s-----------------------------------------------\n";
  char bufstr[1024];

  os << '\n';
  sprintf(bufstr, sepfmt, "--- Run ---");
  os << bufstr;

  os << "MaBoSS version: " << MaBEstEngine::VERSION << " [networks up to " << MAXNODES << " nodes]\n";
  os << "Run start time: " << ctime(&start_time);
  os << "Core run time: " << (mabest.getCoreRunTime()/1000.) << " secs using " << thread_count << " thread" << (thread_count > 1 ? "s" : "") << "\n";
  os << "Display time: " << (mabest.getDisplayTime()/1000.) << " secs using 1 thread\n";
  os << "Run end time: " << ctime(&end_time);
  os << "Time Tick: " << getTimeTick() << '\n';
  os << "Max Time: " <<getMaxTime() << '\n';
  os << "Sample Count: " << getSampleCount() << '\n';
  os << "StatDist Trajectory Count: " << getStatDistTrajCount() << '\n';
  os << "StatDist Similarity Cache Maximum Size: " << getStatDistSimilarityCacheMaxSize() << '\n';
  os << "Discrete Time: " << (isDiscreteTime() ? "TRUE" : "FALSE") << '\n';
  os << "Random Generator: " << getRandomGeneratorFactory()->getName() << '\n';
  if (getRandomGeneratorFactory()->isPseudoRandom()) {
    os << "Seed Pseudo Random: " << getSeedPseudoRandom() << '\n';
  }

  sprintf(bufstr, sepfmt, "-----------");
  os << bufstr << '\n';

  sprintf(bufstr, sepfmt, "- Network -");
  os << bufstr;
  network->display(os);
  sprintf(bufstr, sepfmt, "-----------");
  os << bufstr << '\n';

  sprintf(bufstr, sepfmt, " Variables ");
  os << bufstr;
  SymbolTable::getInstance()->display(os);
  sprintf(bufstr, sepfmt, "-----------");
  os << bufstr << '\n';
}

int RunConfig::parse(Network* network, const char* file)
{
  extern FILE* RCin;
  extern int RCparse();
  extern void runconfig_setNetwork(Network* network);
  runconfig_setNetwork(network);
  if (NULL != file) {
    RCin = fopen(file, "r");
    if (RCin == NULL) {
      throw BNException("variable parsing: cannot open file:" + std::string(file) + " for reading");
    }
  }

  return RCparse();
}

