/* 
   MaBoSS (Markov Boolean Stochastic Simulator)
   Copyright (C) 2011 Institut Curie, 26 rue d'Ulm, Paris, France
   
   MaBoSS is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   MaBoSS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/*
   Module:
     MaBoSS.cc

   Authors:
     Eric Viara <viara@sysra.com>
     Gautier Stoll <gautier.stoll@curie.fr>
 
   Date:
     January-March 2011
*/

#include "MaBEstEngine.h"
#include <fstream>
#include <stdlib.h>

static int usage(const char* prog)
{
  std::cerr << "usage: " << prog << " [-version] -c CONF_FILES... -o OUTPUT BOOLEAN_NETWORK_FILE\n";
  return 1;
}

int main(int argc, char* argv[])
{
  const char* output = NULL;
  std::vector<std::string> runconfig_file_v;
  const char* ctbndl_file = NULL;

  for (unsigned int nn = 1; nn < argc; ++nn) {
    const char* s = argv[nn];
    if (!strcmp(s, "-version")) {
      std::cout << "MaBoSS version " + MaBEstEngine::VERSION << " [networks up to " << MAXNODES << " nodes]\n";
      return 0;
    } else if (!strcmp(s, "-o")) {
      output = argv[++nn];
    } else if (!strcmp(s, "-c")) {
      runconfig_file_v.push_back(argv[++nn]);
    } else if (*s == '-') {
      return usage(argv[0]);
    } else if (NULL != ctbndl_file) {
      return usage(argv[0]);
    } else {
      ctbndl_file = argv[nn];
    }
  }

  if (NULL == ctbndl_file || output == NULL) {
    return usage(argv[0]);
  }
    
  std::ostream* output_run = NULL;
  std::ostream* output_traj = NULL;
  std::ostream* output_probtraj = NULL;
  std::ostream* output_statdist = NULL;

  try {
    time_t start_time, end_time;
    SymbolTable* symtab = SymbolTable::getInstance();
    Network* network = new Network();

    network->parse(ctbndl_file);

    RunConfig* runconfig = RunConfig::getInstance();

    std::vector<std::string>::const_iterator begin = runconfig_file_v.begin();
    std::vector<std::string>::const_iterator end = runconfig_file_v.end();
    while (begin != end) {
      runconfig->parse(network, (*begin).c_str());
      ++begin;
    }

    if (runconfig->displayTrajectories()) {
      if (runconfig->getThreadCount() > 1) {
	std::cerr << "Warning: cannot display trajectories in multi-threaded mode\n";
      } else {
	output_traj = new std::ofstream((std::string(output) + "_traj.txt").c_str());
      }
    }

    output_run = new std::ofstream((std::string(output) + "_run.txt").c_str());
    output_probtraj = new std::ofstream((std::string(output) + "_probtraj.csv").c_str());
    output_statdist = new std::ofstream((std::string(output) + "_statdist.csv").c_str());

    time(&start_time);
    MaBEstEngine mabest(network, runconfig);
    mabest.run(output_traj);

    mabest.display(*output_probtraj, *output_statdist);

    time(&end_time);

    runconfig->display(network, start_time, end_time, mabest, *output_run);

    ((std::ofstream*)output_run)->close();
    if (NULL != output_traj) {
      ((std::ofstream*)output_traj)->close();
    }
    ((std::ofstream*)output_probtraj)->close();
    ((std::ofstream*)output_statdist)->close();
  } catch(const BNException& e) {
    std::cerr << e;
    return 1;
  }

  return 0;
}
